npm create vite .
npm i
npm i @mui/material @emotion/react @emotion/styled
npm i react-router-dom
npm i axios
npm i @mui/icons-material
npm i @mui/x-date-pickers
npm i dayjs
npm i formik yup
npm i react-toastify

npm rm @mui/material @emotion/react @emotion/styled @mui/icons-material @mui/x-date-pickers
npm rm react-router-dom axios dayjs formik yup react-toastify

npm i @mui/material @emotion/react @emotion/styled @mui/icons-material @mui/x-date-pickers
npm i react-router-dom axios dayjs formik yup react-toastify
